export interface ApiResponseSingle {
    rs_code: string,
    response: any,
    errorMsg: string
  }